# Project Files: Composing Complex Interfaces

To follow the [Composing Complex Interfaces](https://developer.apple.com/tutorials/swiftui/composing-complex-interfaces) tutorial, open the Xcode project in the **StartingPoint** folder. To explore on your own, open the Xcode project in the **Complete** folder and browse the project's code.

- Note: To preview and interact with views from the canvas in Xcode ensure your Mac is running macOS 10.15 or later.
